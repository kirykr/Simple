<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1><i class="fa fa-plus"></i> Categories / Create </h1>
    </div>

    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

        <?php /* <form action="<?php echo e(route('categories.store')); ?>" method="POST"> */ ?>    
            <?php echo Form::open(['action'=>"CategoryController@store", 'method'=>"POST",'files'=>true]); ?>

            <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   
                <div class="row">
                    <div class="col-md-7">
                        <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                        <?php echo Form::label('name', 'Name', []); ?>

                        <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

                       <?php if($errors->has("name")): ?>
                        <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                       <?php endif; ?>
                </div>
                    </div>
                    <div class="col-md-5">
                         <?php echo Form::label('type_id', 'Computer Type'); ?>

                  <div class="form-group <?php echo e($errors->has('type_id') ? 'has-error' :''); ?>">
                    <?php echo Form::select('type_id',[''=>'Choose Options'] + $types,0,['class'=>'form-control']); ?>

                    <?php echo $errors->first('type_id','<span class="help-block">:message</span>'); ?>

                    </div>
                    </div>
                </div>
                
                 <?php echo Form::label('description', 'Category Description'); ?>

              <div class="form-group <?php echo e($errors->has('description') ? 'has-error' :''); ?>">
                <?php echo Form::textarea('description',null,['class'=>'form-control','placeholder'=>'Category desc']); ?>

                <?php echo $errors->first('description','<span class="help-block">:message</span>'); ?>

             </div>
               
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Create</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.categories.index')); ?>"><i class="fa fa-backward"></i> Back</a>
                </div>
            <?php echo Form::close(); ?>

            <?php /* </form> */ ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <?php /* <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script> */ ?>
  <script>
    $('.date-picker').datepicker({
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>