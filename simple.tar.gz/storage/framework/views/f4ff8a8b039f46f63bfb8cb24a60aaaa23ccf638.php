<?php $__env->startSection('content'); ?>

<?php /* <?php $__env->startSection('header'); ?> */ ?>
    <div class="page-header clearfix">
        <h1>
            <i class="fa fa-align-justify"></i> Suppliers
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.suppliers.create')); ?>"><i class="fa fa-plus"></i> Create</a>
        </h1>

    </div>
<?php /* <?php $__env->stopSection(); ?> */ ?>
    p
    <div class="row">
        <div class="col-md-12">
            <?php if($suppliers->count()): ?>
                <table class="table table-condensed table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAME</th>
                        <th>CONTACTPERSON</th>
                        <th>TEL</th>
                        <th>ADDRESS</th>
                            <th class="text-right">OPTIONS</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach($suppliers as $supplier): ?>
                            <tr>
                                <td><?php echo e($supplier->id); ?></td>
                                <td><?php echo e($supplier->name); ?></td>
                    <td><?php echo e($supplier->contactperson); ?></td>
                    <td><?php echo e($supplier->tel); ?></td>
                    <td><?php echo e($supplier->address); ?></td>
                                <td class="text-right">
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.suppliers.show', $supplier->id)); ?>"><i class="fa fa-eye"></i> View</a>
                                    <a class="btn btn-xs btn-warning" href="<?php echo e(route('admin.suppliers.edit', $supplier->id)); ?>"><i class="fa fa-edit"></i> Edit</a>
                                    <form action="<?php echo e(route('admin.suppliers.destroy', $supplier->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php echo $suppliers->render(); ?>

            <?php else: ?>
                <h3 class="text-center alert alert-info">Empty!</h3>
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>