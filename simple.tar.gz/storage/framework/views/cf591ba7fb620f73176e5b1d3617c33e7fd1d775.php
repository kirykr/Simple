<?php $__env->startSection('content'); ?>
<?php /* <?php $__env->startSection('header'); ?> */ ?>
    <div class="page-header">
        <h1><i class="fa fa-edit"></i> Roles / Edit #<?php echo e($role->id); ?></h1>
    </div>
<?php /* <?php $__env->stopSection(); ?> */ ?>


    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

        <?php /* <form action="<?php echo e(route('admin.roles.update', $role->id)); ?>" method="POST">  */ ?>   
            <?php echo Form::model($role,['action' => ['RoleController@update', $role->id], 'method' => 'PATCH', 'files'=>true]); ?>

            <?php /*
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            */ ?>
               <?php /*  <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                       <label for="name-field">Name</label>
                    <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(is_null(old("name")) ? $role->name : old("name")); ?>"/>
                   <?php if($errors->has("name")): ?>
                    <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                   <?php endif; ?>
                </div> */ ?>
                <div class="row">
                    <div class="col-md-3"><?php echo Form::label('name', 'Role Name'); ?>

                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
                          <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Role name']); ?>

                          <?php echo $errors->first('name','<span class="help-block">:message</span>'); ?>

                        </div>
                    </div>
                    <div class="col-md-4">
                  <div class="form-group <?php if($errors->has('display_name')): ?> has-error <?php endif; ?>">
                       <label for="display_name-field">Role display_name</label>
                    <input type="text" id="display_name-field" name="display_name" class="form-control" value="<?php echo e(old("display_name")); ?>"/>
                       <?php if($errors->has("display_name")): ?>
                        <span class="help-block"><?php echo e($errors->first("display_name")); ?></span>
                       <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                   <div class="form-group <?php if($errors->has('description')): ?> has-error <?php endif; ?>">
                       <label for="description-field">Role Description</label>
                    <input type="text" id="description-field" name="description" class="form-control" value="<?php echo e(old("description")); ?>"/>
                       <?php if($errors->has("description")): ?>
                        <span class="help-block"><?php echo e($errors->first("description")); ?></span>
                       <?php endif; ?>
                    </div>
                </div>
                </div>
                  <div class="row ">
                  <div class="col-md-2 wel">
                    <h5><strong>All</strong></h5>
                    <input type="checkbox" id="checkAll" value="">
                  </div>
                  <?php /* loops for check box */ ?>
                  <?php foreach($permissions as $permission): ?>
                  <div class="col-md-2">
                    <h5><strong><?php echo e(ucfirst($permission->name)); ?></strong></h5>
                    <?php /* <input type="checkbox" name="permission[]" value="<?php echo e($permission->id); ?>"> */ ?>
                    <?php echo Form::checkbox('permission_id[]', $permission->id,  $role->hasPermission($permission->name), ['class'=>'form-control']); ?>

                  </div>
                <?php endforeach; ?>
                </div>
                <hr>
                <br><br>
                <div class="well well-sm">
                    <?php /*  <button type="submit" class="btn btn-primary">Save</button> */ ?>
                    <?php echo Form::submit('Save', ['class'=>'btn btn-primary']); ?>

                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.roles.index')); ?>"><i class="fa fa-backward"></i>  Back</a>
                </div>
            </form>
            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $('.date-picker').datepicker({
    });

    // check all uncheck all
    $("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>