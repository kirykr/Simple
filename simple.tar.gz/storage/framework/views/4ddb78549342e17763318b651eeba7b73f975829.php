<?php $__env->startSection('header'); ?>
    <div class="page-header">
        <h1><i class="fa fa-plus"></i> Roles / Create </h1>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

        <?php /* <form action="<?php echo e(route('admin.rolesController.store')); ?>" method="POST"> */ ?>    
            <?php echo Form::open(['action'=>"RoleController@store", 'method'=>"POST",'files'=>true]); ?>

            <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   
              <div class="row">
              <div class="col-md-4">
                    <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                       <label for="name-field">Role Name</label>
                    <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(old("name")); ?>"/>
                       <?php if($errors->has("name")): ?>
                        <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                       <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group <?php if($errors->has('display_name')): ?> has-error <?php endif; ?>">
                       <label for="display_name-field">Role display_name</label>
                    <input type="text" id="display_name-field" name="display_name" class="form-control" value="<?php echo e(old("display_name")); ?>"/>
                       <?php if($errors->has("display_name")): ?>
                        <span class="help-block"><?php echo e($errors->first("display_name")); ?></span>
                       <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                   <div class="form-group <?php if($errors->has('description')): ?> has-error <?php endif; ?>">
                       <label for="description-field">Role Description</label>
                    <input type="text" id="description-field" name="description" class="form-control" value="<?php echo e(old("description")); ?>"/>
                       <?php if($errors->has("description")): ?>
                        <span class="help-block"><?php echo e($errors->first("description")); ?></span>
                       <?php endif; ?>
                    </div>
                </div>
              </div>
                <div class="row">
                  <div class="col-md-2 wel">
                    <h5><strong>All</strong></h5>
                    <input type="checkbox"  class="select_all" value="">
                  </div>
                  <?php foreach($permissions as $permission): ?>
                  <div class="col-md-2">
                    <h5><strong><?php echo e(ucfirst($permission->name)); ?></strong></h5>
                    <input class="categories_list" type="checkbox" name="permission_id[]" value="<?php echo e($permission->id); ?>">
                  </div>
                <?php endforeach; ?>
                </div>
                <hr><br><br>
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Create</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.roles.index')); ?>"><i class="fa fa-backward"></i> Back</a>
                </div>
            <?php echo Form::close(); ?>

            <?php /* </form> */ ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <?php /* <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script> */ ?>
  <script>
    $('.date-picker').datepicker({
    });

// check all uncheck all
    // $("#checkAll").change(function () {
    // $("input:checkbox").prop('checked', $(this).prop("checked"));
    // });

    $(function() {
    $("input[type=checkbox]").change(function() {
        var count_checkbox_all = $("input[type=checkbox]").not(".select_all").length;
        var count_checkbox_checked = $("input[type=checkbox]:checked").not(".select_all").length;

        if ($(this).hasClass("select_all")) { 
            //if we clicked on "Select All"
            var is_checked = $(".select_all").is(":checked");
            //check/uncheck everything and disable/enable the rest of the tickboxes based on the state of this one
            $(".categories_list").prop("checked", is_checked).attr("disabled",  is_checked);
            
            //also update the count of checked items
            count_checkbox_checked = $("input[type=checkbox]:checked").not(".select_all").length;
        }
        
        if (count_checkbox_checked == count_checkbox_all) { //if all have been checked
            //make sure they are disabled and that "Select All" is checked as well
            $(".categories_list").attr("disabled",  true);
            $(".select_all").prop("checked", true);
        }
        
    });   
});
    //// get checked checkbox value
    // $('input').on('click', function(){
    // var selected = [];
    // $('.data input:checked').each(function() {
    //      selected.push($(this).val());
    // });

    //Or
    /*
    var checkboxes = document.getElementsByName('employee');
    var selected = [];
      for (var i=0; i<checkboxes.length; i++) {
         if (checkboxes[i].checked) {
            selected.push(checkboxes[i].value);
         }
      }
    */
      // alert(selected);
    // });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>