<?php $__env->startSection('content'); ?>
<div class="page-header">
  <h1><i class="fa fa-plus"></i> Cimports / Create </h1>
</div>

<?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
  <div class="col-md-12">

    <?php /* <form action="<?php echo e(route('admin.cimportsController.store')); ?>" method="POST"> */ ?>    
    <?php echo Form::open(['action'=>"CimportController@store", 'method'=>"POST",'files'=>true]); ?>

    <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   
    <div class="row">
      <div class="col-md-3">
        <div class="form-group <?php if($errors->has('impdate')): ?> has-error <?php endif; ?>">
         <label for="impdate-field">Import Date</label>
         <?php /* <input type="text" id="impdate-field" name="impdate" class="form-control date-picker" value="<?php echo e(old("impdate")); ?>"/> */ ?>
         <?php echo Form::date('impdate', \Carbon\Carbon::now(), ['class'=>'form-control', 'value'=> "<?php echo e(old('impdate')); ?>" ]); ?>


         <?php if($errors->has("impdate")): ?>
         <span class="help-block"><?php echo e($errors->first("impdate")); ?></span>
         <?php endif; ?>
       </div>
     </div>
     <div class="col-md-3">
      <div class="form-group <?php if($errors->has('impindate')): ?> has-error <?php endif; ?>">
       <label for="impindate-field">ImportIn Date</label>
       <?php /* <input type="text" id="impindate-field" name="impindate" class="form-control date-picker" value="<?php echo e(old("impindate")); ?>"/> */ ?>
       <?php echo Form::date('impindate', \Carbon\Carbon::now(), ['class'=>'form-control', 'value'=> "<?php echo e(old('impindate')); ?>" ]); ?>

       <?php if($errors->has("impindate")): ?>
       <span class="help-block"><?php echo e($errors->first("impindate")); ?></span>
       <?php endif; ?>
     </div>     
   </div>
   <div class="col-md-3">
     <div class="form-group <?php if($errors->has('invoicenum')): ?> has-error <?php endif; ?>">
         <label for="invoicenum-field">Invoice Number</label>
         <input type="text" id="invoicenum-field" name="invoicenum" class="form-control" value="<?php echo e(old("invoicenum")); ?>"/>
         <?php if($errors->has("invoicenum")): ?>
         <span class="help-block"><?php echo e($errors->first("invoicenum")); ?></span>
         <?php endif; ?>
      </div>
   </div>
   <div class="col-md-3">
     <div class="form-group <?php if($errors->has('totalamount')): ?> has-error <?php endif; ?>">
       <label for="totalamount-field">Total Amount</label>
       <input type="text" id="totalamount-field" name="totalamount" class="form-control" value="<?php echo e(old("totalamount")); ?>"/>
       <?php if($errors->has("totalamount")): ?>
       <span class="help-block"><?php echo e($errors->first("totalamount")); ?></span>
       <?php endif; ?>
     </div>
   </div>
 </div>
 <div class="row">
   <div class="col-md-3">
     <div class="form-group <?php if($errors->has('user_id')): ?> has-error <?php endif; ?>">
       <label for="user_id-field">User</label>
       <input type="text" id="user_id-field" name="user_id" class="form-control" value="<?php echo e(old("user_id")); ?>"/>
       <?php if($errors->has("user_id")): ?>
       <span class="help-block"><?php echo e($errors->first("user_id")); ?></span>
       <?php endif; ?>
     </div>
   </div>
   <div class="col-md-3">
      <div class="form-group <?php if($errors->has('supplier_id')): ?> has-error <?php endif; ?>">
         <label for="supplier_id-field">Supplier Name</label>
         <input type="text" id="supplier_id-field" name="supplier_id" class="form-control" value="<?php echo e(old("supplier_id")); ?>"/>
         <?php if($errors->has("supplier_id")): ?>
         <span class="help-block"><?php echo e($errors->first("supplier_id")); ?></span>
         <?php endif; ?>
       </div>
   </div>
   <div class="col-md-3"></div>
   <div class="col-md-3"></div>
 </div>
 
<hr>
 <div class="well well-sm">
  <button type="submit" class="btn btn-primary">Create</button>
  <a class="btn btn-link pull-right" href="<?php echo e(route('admin.cimports.index')); ?>"><i class="fa fa-backward"></i> Back</a>
</div>
<?php echo Form::close(); ?>

<?php /* </form> */ ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
<script>
  $('.date-picker').datepicker({
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>