<?php $__env->startSection('content'); ?>
<div class="page-header">
  <h1><i class="fa fa-plus"></i> Oimports / Create </h1>
</div>

<?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
  <div class="col-md-12">

    <?php /* <form action="<?php echo e(route('admin.oimportsController.store')); ?>" method="POST"> */ ?>    
    <?php echo Form::open(['action'=>"OimportController@store", 'method'=>"POST",'files'=>true]); ?>

    <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   
    <div class="row">
      <div class="col-md-3">
       <div class="form-group <?php if($errors->has('impdate')): ?> has-error <?php endif; ?>">
         <label for="impdate-field">Import Date</label>
         <?php /* <input type="text" id="impdate-field" name="impdate" class="form-control date-picker" value="<?php echo e(old("impdate")); ?>"/> */ ?>
         <?php echo Form::date('impdate', \Carbon\Carbon::now(), ['class'=>'form-control', 'value'=> "<?php echo e(old('impdate')); ?>" ]); ?>


         <?php if($errors->has("impdate")): ?>
         <span class="help-block"><?php echo e($errors->first("impdate")); ?></span>
         <?php endif; ?>
       </div>
     </div>
     <div class="col-md-3">
       <div class="form-group <?php if($errors->has('impindate')): ?> has-error <?php endif; ?>">
         <label for="impindate-field">ImportIn Date</label>
         <?php /* <input type="text" id="impindate-field" name="impindate" class="form-control date-picker" value="<?php echo e(old("impindate")); ?>"/> */ ?>
         <?php echo Form::date('impindate', \Carbon\Carbon::now(), ['class'=>'form-control', 'value'=> "<?php echo e(old('impindate')); ?>" ]); ?>

         <?php if($errors->has("impindate")): ?>
         <span class="help-block"><?php echo e($errors->first("impindate")); ?></span>
         <?php endif; ?>
       </div>     
     </div>
     <div class="col-md-3">

      <div class="form-group <?php if($errors->has('invoicenumber')): ?> has-error <?php endif; ?>">
       <label for="invoicenumber-field">Invoicenumber</label>
       <input type="text" id="invoicenumber-field" name="invoicenumber" class="form-control" value="<?php echo e(old("invoicenumber")); ?>"/>
       <?php if($errors->has("invoicenumber")): ?>
       <span class="help-block"><?php echo e($errors->first("invoicenumber")); ?></span>
       <?php endif; ?>
     </div>
   </div>
   <div class="col-md-3">
    <div class="form-group <?php if($errors->has('totalamount')): ?> has-error <?php endif; ?>">
     <label for="totalamount-field">Totalamount</label>
     <input type="text" id="totalamount-field" name="totalamount" class="form-control" value="<?php echo e(old("totalamount")); ?>"/>
     <?php if($errors->has("totalamount")): ?>
     <span class="help-block"><?php echo e($errors->first("totalamount")); ?></span>
     <?php endif; ?>
   </div>
 </div>
  <div class="col-md-3">
    <div class="form-group <?php if($errors->has('user_id')): ?> has-error <?php endif; ?>">
 <label for="user_id-field">User_id</label>
 <input type="text" id="user_id-field" name="user_id" class="form-control" value="<?php echo e(old("user_id")); ?>"/>
 <?php if($errors->has("user_id")): ?>
 <span class="help-block"><?php echo e($errors->first("user_id")); ?></span>
 <?php endif; ?>
</div>
  </div>
   <div class="col-md-3">
     <div class="form-group <?php if($errors->has('supplier_id')): ?> has-error <?php endif; ?>">
 <label for="supplier_id-field">Supplier_id</label>
 <input type="text" id="supplier_id-field" name="supplier_id" class="form-control" value="<?php echo e(old("supplier_id")); ?>"/>
 <?php if($errors->has("supplier_id")): ?>
 <span class="help-block"><?php echo e($errors->first("supplier_id")); ?></span>
 <?php endif; ?>
</div>
   </div>
</div>




<div class="well well-sm">
  <button type="submit" class="btn btn-primary">Create</button>
  <a class="btn btn-link pull-right" href="<?php echo e(route('admin.oimports.index')); ?>"><i class="fa fa-backward"></i> Back</a>
</div>
<?php echo Form::close(); ?>

<?php /* </form> */ ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
<script>
  $('.date-picker').datepicker({
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>