<?php $__env->startSection('content'); ?>

<?php /* <?php $__env->startSection('header'); ?> */ ?>
    <div class="page-header">
        <h1><i class="fa fa-edit"></i> Modells / Edit #<?php echo e($modell->id); ?></h1>
    </div>
<?php /* <?php $__env->stopSection(); ?> */ ?>

    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

        <?php /* <form action="<?php echo e(route('admin.modells.update', $modell->id)); ?>" method="POST">  */ ?>   
            <?php echo Form::model($modell,['action' => ['ModellController@update', $modell->id], 'method' => 'PATCH', 'files'=>true]); ?>

            <?php /*
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            */ ?>
               <div class="row">
               <div class="col-md-8">
                 <?php echo Form::label('name', 'Model Name'); ?>

                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
                  <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Model Name']); ?>

                  <?php echo $errors->first('name','<span class="help-block">:message</span>'); ?>

               </div>
               </div>
               <div class="col-md-4">
                 <?php echo Form::label('category_id', 'Category Name'); ?>

                <div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' :''); ?>">
                  <?php echo Form::select('category_id',[''=>'Choose Options'] + $categories, 0,['class'=>'form-control']); ?>

                  <?php echo $errors->first('category_id','<span class="help-block">:message</span>'); ?>

                </div>
               </div>
             </div> 
              

              <?php echo Form::label('description', 'Model Description'); ?>

              <div class="form-group <?php echo e($errors->has('description') ? 'has-error' :''); ?>">
                <?php echo Form::textarea('description',null,['class'=>'form-control','placeholder'=>'Model desc']); ?>

                <?php echo $errors->first('description','<span class="help-block">:message</span>'); ?>

             </div>
             

                <div class="well well-sm">
                    <?php /*  <button type="submit" class="btn btn-primary">Save</button> */ ?>
                    <?php echo Form::submit('Save', ['class'=>'btn btn-primary']); ?>

                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.modells.index')); ?>"><i class="fa fa-backward"></i>  Back</a>
                </div>
            </form>
            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $('.date-picker').datepicker({
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>