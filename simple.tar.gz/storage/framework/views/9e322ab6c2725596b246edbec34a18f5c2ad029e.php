<?php $__env->startSection('content'); ?>
<?php /* <?php $__env->startSection('header'); ?> */ ?>
<div class="page-header">
  <h1><i class="fa fa-plus"></i> Others / Create </h1>
</div>
<?php /* <?php $__env->stopSection(); ?> */ ?>


<?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
  <div class="col-md-12">

    <?php /* <form action="<?php echo e(route('othersController.store')); ?>" method="POST"> */ ?>    
    <?php echo Form::open(['action'=>"OtherController@store", 'method'=>"POST",'files'=>true]); ?>

    <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   
    <?php /* error for Other product Code */ ?>
     <?php /* <?php echo Form::label('comcode', 'Other product Code'); ?>

     <div class="form-group <?php echo e($errors->has('comcode') ? 'has-error' :''); ?>">
        <?php echo Form::text('comcode',null,['class'=>'form-control','placeholder'=>'Other product Code']); ?>

        <?php echo $errors->first('comcode','<span class="help-block">:message</span>'); ?>

      </div> */ ?>
      <div class="row">
        <div class="col-md-4">
         <?php /* for Other product Name */ ?>
         <?php echo Form::label('name', 'Other product Name'); ?>

         <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
          <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Other product Name']); ?>

          <?php echo $errors->first('name','<span class="help-block">:message</span>'); ?>

        </div>
      </div>
       <div class="col-md-2">
          <?php echo Form::label('sellprice', 'Sell Price'); ?>

          <div class="form-group <?php echo e($errors->has('sellprice') ? 'has-error' :''); ?>">
            <?php echo Form::number('sellprice',0,['class'=>'form-control','step'=>'any','placeholder'=>'Computer sellprice']); ?>

            <?php echo $errors->first('sellprice','<span class="help-block">:message</span>'); ?>

          </div>
        </div>
        <div class="col-md-2">
          <?php echo Form::label('ppprice', 'PP Price'); ?>

          <div class="form-group <?php echo e($errors->has('ppprice') ? 'has-error' :''); ?>">
            <?php echo Form::number('ppprice',0,['class'=>'form-control','step'=>'any','placeholder'=>'Computer ppprice']); ?>

            <?php echo $errors->first('ppprice','<span class="help-block">:message</span>'); ?>

          </div>
        </div>
        <div class="col-md-2">
          <?php echo Form::label('provprice', 'Province Price'); ?>

          <div class="form-group <?php echo e($errors->has('provprice') ? 'has-error' :''); ?>">
            <?php echo Form::number('provprice',0,['class'=>'form-control','step'=>'any','placeholder'=>'Computer provprice']); ?>

            <?php echo $errors->first('provprice','<span class="help-block">:message</span>'); ?>

          </div>
        </div>
        <div class="col-md-2">
          <?php echo Form::label('status', 'Status'); ?>

          <div class="form-group <?php echo e($errors->has('status') ? 'has-error' :''); ?>">
            <?php echo Form::number('status',0,['class'=>'form-control','step'=>'any','placeholder'=>'Computer status']); ?>

            <?php echo $errors->first('status','<span class="help-block">:message</span>'); ?>

          </div>
        </div>
      <div class="col-md-3">
          <?php echo Form::label('name', 'Computer Specs'); ?>

          <div class="form-group">
            <a class="btn btn-block btn-success" data-toggle="modal" href='#modal-id'>Add Specs</a>
          </div>
      </div>
    </div>
    <?php echo Form::label('photo_id', 'Other product Picture'); ?>

    <div class="form-group <?php echo e($errors->has('photo_id') ? 'has-error' :''); ?>">
      <?php /* <?php echo Form::file('photo_id',null,['class'=>'','placeholder'=>'Other product photo_id']); ?> */ ?>
      <?php echo Form::file('photo_id[]', ['multiple'=>'true', 'class'=>'file-loading', 'id'=>'input-pd']); ?>

      <?php echo $errors->first('photo_id','<span class="help-block">:message</span>'); ?>

    </div>
     <div class="row">
      <div class="col-md-3">
        <?php echo Form::label('brand_id', 'Computer Brand'); ?>

        <div class="form-group <?php echo e($errors->has('brand_id') ? 'has-error' :''); ?>">
          <?php echo Form::select('brand_id',[''=>'Choose Options']+ $brands,0,['class'=>'form-control','id'=>'computer_brand']); ?>

          <?php echo $errors->first('brand_id','<span class="help-block">:message</span>'); ?>

        </div>
      </div>
      <div class="col-md-3">
        <?php echo Form::label('type_id', 'Computer Type'); ?>

        <div class="form-group <?php echo e($errors->has('type_id') ? 'has-error' :''); ?>">
          <?php echo Form::select('type_id',[''=>'Choose Options'],0,['class'=>'form-control']); ?>

          <?php echo $errors->first('type_id','<span class="help-block">:message</span>'); ?>

        </div>
      </div>
      <div class="col-md-3">
        <?php echo Form::label('category_id', 'Computer Categories'); ?>

        <div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' :''); ?>">
          <?php echo Form::select('category_id',[''=>'Choose Options'],0,['class'=>'form-control']); ?>

          <?php echo $errors->first('category_id','<span class="help-block">:message</span>'); ?>

        </div>
      </div>

      <div class="col-md-3">
        <?php echo Form::label('model_id', 'Computer Model'); ?>

        <div class="form-group <?php echo e($errors->has('model_id') ? 'has-error' :''); ?>">
          <?php echo Form::select('model_id',[''=>'Choose Options'],0,['class'=>'form-control']); ?>

          <?php echo $errors->first('model_id','<span class="help-block">:message</span>'); ?>

        </div>
      </div>
  </div>

    <div class="well well-sm">
      <button type="submit" class="btn btn-primary">Create</button>
      <a class="btn btn-link pull-right" href="<?php echo e(route('admin.others.index')); ?>"><i class="fa fa-backward"></i> Back</a>
    </div>
    <?php echo Form::close(); ?>

    <?php /* </form> */ ?>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php /* <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script> */ ?>
<script>
    // $('.date-picker').datepicker({
    // });
  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>