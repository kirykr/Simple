<?php $__env->startSection('content'); ?>

<?php /* <?php $__env->startSection('header'); ?> */ ?>
    <div class="page-header">
        <h1><i class="fa fa-plus"></i> Suppliers / Create </h1>
    </div>
<?php /* <?php $__env->stopSection(); ?> */ ?>

    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

        <?php /* <form action="<?php echo e(route('admin.suppliersController.store')); ?>" method="POST"> */ ?>    
            <?php echo Form::open(['action'=>"SupplierController@store", 'method'=>"POST",'files'=>true]); ?>

            <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   

                <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                       <label for="name-field">Name</label>
                    <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(old("name")); ?>"/>
                       <?php if($errors->has("name")): ?>
                        <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                       <?php endif; ?>
                    </div>
                    <div class="form-group <?php if($errors->has('contactperson')): ?> has-error <?php endif; ?>">
                       <label for="contactperson-field">Contactperson</label>
                    <input type="text" id="contactperson-field" name="contactperson" class="form-control" value="<?php echo e(old("contactperson")); ?>"/>
                       <?php if($errors->has("contactperson")): ?>
                        <span class="help-block"><?php echo e($errors->first("contactperson")); ?></span>
                       <?php endif; ?>
                    </div>
                    <div class="form-group <?php if($errors->has('tel')): ?> has-error <?php endif; ?>">
                       <label for="tel-field">Tel</label>
                    <input type="text" id="tel-field" name="tel" class="form-control" value="<?php echo e(old("tel")); ?>"/>
                       <?php if($errors->has("tel")): ?>
                        <span class="help-block"><?php echo e($errors->first("tel")); ?></span>
                       <?php endif; ?>
                    </div>
                    <div class="form-group <?php if($errors->has('address')): ?> has-error <?php endif; ?>">
                       <label for="address-field">Address</label>
                    <textarea class="form-control" id="address-field" rows="3" name="address"><?php echo e(old("address")); ?></textarea>
                       <?php if($errors->has("address")): ?>
                        <span class="help-block"><?php echo e($errors->first("address")); ?></span>
                       <?php endif; ?>
                    </div>
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Create</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.suppliers.index')); ?>"><i class="fa fa-backward"></i> Back</a>
                </div>
            <?php echo Form::close(); ?>

            <?php /* </form> */ ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $('.date-picker').datepicker({
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>