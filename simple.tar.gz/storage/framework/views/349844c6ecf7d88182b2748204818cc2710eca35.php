<?php $__env->startSection('content'); ?>
<?php $__env->startSection('header'); ?>
    <div class="page-header">
        <h1><i class="fa fa-plus"></i> Permissions / Create </h1>
    </div>
<?php $__env->stopSection(); ?>

    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

        <?php /* <form action="<?php echo e(route('admin.permissionsController.store')); ?>" method="POST"> */ ?>    
            <?php echo Form::open(['action'=>"PermissionController@store", 'method'=>"POST",'files'=>true]); ?>

            <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   

                <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                       <label for="name-field">Name</label>
                    <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(old("name")); ?>"/>
                       <?php if($errors->has("name")): ?>
                        <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                       <?php endif; ?>
                    </div>
                    <div class="form-group <?php if($errors->has('display_name')): ?> has-error <?php endif; ?>">
                       <label for="display_name-field">Display_name</label>
                    <input type="text" id="display_name-field" name="display_name" class="form-control" value="<?php echo e(old("display_name")); ?>"/>
                       <?php if($errors->has("display_name")): ?>
                        <span class="help-block"><?php echo e($errors->first("display_name")); ?></span>
                       <?php endif; ?>
                    </div>
                    <div class="form-group <?php if($errors->has('discription')): ?> has-error <?php endif; ?>">
                       <label for="discription-field">Discription</label>
                    <textarea class="form-control" id="discription-field" rows="3" name="discription"><?php echo e(old("discription")); ?></textarea>
                       <?php if($errors->has("discription")): ?>
                        <span class="help-block"><?php echo e($errors->first("discription")); ?></span>
                       <?php endif; ?>
                    </div>
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Create</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.permissions.index')); ?>"><i class="fa fa-backward"></i> Back</a>
                </div>
            <?php echo Form::close(); ?>

            <?php /* </form> */ ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $('.date-picker').datepicker({
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>