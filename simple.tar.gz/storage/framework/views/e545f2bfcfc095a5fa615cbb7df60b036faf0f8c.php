\
<?php $__env->startSection('content'); ?>
<?php /* <?php $__env->startSection('header'); ?> */ ?>
    <div class="page-header clearfix">
        <h1>
            <i class="fa fa-align-justify"></i> Types
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.types.create')); ?>"><i class="fa fa-plus"></i> Create</a>
        </h1>

    </div>
<?php /* <?php $__env->stopSection(); ?> */ ?>

    <div class="row">
        <div class="col-md-12">
            <?php if($types->count()): ?>
                <table class="table table-condensed table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAME</th>
                        <th>DESCRIPTION</th>
                        <th>BRAND NAME</th>
                            <th class="text-right">OPTIONS</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach($types as $type): ?>
                            <tr>
                                <td><?php echo e($type->id); ?></td>
                                <td><?php echo e($type->name); ?></td>
                    <td><?php echo e($type->description); ?></td>
                    <td><?php echo e($type->brand ? $type->brand->name: ''); ?></td>
                                <td class="text-right">
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.types.show', $type->id)); ?>"><i class="fa fa-eye"></i> View</a>
                                    <a class="btn btn-xs btn-warning" href="<?php echo e(route('admin.types.edit', $type->id)); ?>"><i class="fa fa-edit"></i> Edit</a>
                                    <form action="<?php echo e(route('admin.types.destroy', $type->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php echo $types->render(); ?>

            <?php else: ?>
                <h3 class="text-center alert alert-info">Empty!</h3>
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>