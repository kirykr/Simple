<?php $__env->startSection('content'); ?>
    <div class="page-header clearfix">
        <h1>
            <i class="fa fa-align-justify"></i> Computers
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.computers.create')); ?>"><i class="fa fa-plus"></i> Create</a>
        </h1>

    </div>

    <div class="row">
        <div class="col-md-12">
            <?php if($computers->count()): ?>
                <table class="table table-condensed table-striped">
                    <thead>
                        <tr>
                        <th>ID</th>
                        <th>PHOTO</th>
                        <th>NAME</th>
                        <th>QTY</th>
                        <th>PRICE</th>
                        <th>BRAND</th>
                        <th>PP PRICE</th>
                        <th>PRO PRICE</th>
                        <th>STATUS</th>
                            <th class="text-right">OPTIONS</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach($computers as $computer): ?>
                            <tr>
                                <td><?php echo e($computer->id); ?></td>
                                <?php /* <?php echo e(dd( $computer->photos->first()->path )); ?> */ ?>
                                <td><img width="70" src=" <?php echo e($computer->photos->first() ? $computer->photos->first()->path : ''); ?> " alt=""></td>
                                <td><?php echo e($computer->name); ?></td>
                                <td><?php echo e($computer->qtyinstock); ?></td>
                                <td><?php echo e($computer->sellprice); ?></td>
                                <td><?php echo e($computer->brand_id); ?></td>
                                <td><?php echo e($computer->ppprice); ?></td>
                                <td><?php echo e($computer->provprice); ?></td>
                                <td><?php echo e($computer->status); ?></td>
                                <td class="text-right">
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.computers.show', $computer->id)); ?>"><i class="fa fa-eye"></i> View</a>
                                    <a class="btn btn-xs btn-warning" href="<?php echo e(route('admin.computers.edit', $computer->id)); ?>"><i class="fa fa-edit"></i> Edit</a>
                                    <form action="<?php echo e(route('admin.computers.destroy', $computer->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php echo $computers->render(); ?>

            <?php else: ?>
                <h3 class="text-center alert alert-info">Empty!</h3>
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>