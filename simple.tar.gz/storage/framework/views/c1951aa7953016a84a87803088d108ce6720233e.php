<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('errors.formError', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	 <div class="panel panel-info">
   	<div class="panel-heading">
   		<h1 class="panel-title"><i class="fa fa-cogs fa-2x"></i> Edit Users</h1>
   	</div>
   	<div class="panel-body">
   		<?php /* <form action="<?php echo e(url('/posts')); ?>" method="POST"> */ ?>
       <?php /* <?php echo e(csrf_field()); ?>  */ ?>
         <div class="col-md-2">
            <img src="<?php echo e($user->photo?$user->photo->path:'/images/default.jgp'); ?>" class="img-responsive img-circle" alt="Image">
         </div>
         <div class="col-md-10">
            <?php echo Form::model($user,['action' => ['AdminUserController@update', $user->id], 'method' => 'PATCH', 'files'=>true]); ?>

             <?php /* <?php echo csrf_field(); ?> */ ?>
                  <legend><?php echo e(ucfirst($user->name)); ?></legend>
               
                  <div class="form-group">
                     <?php echo Form::label('name', 'User Name:'); ?>

                     <?php echo Form::text('name', null,['class'=>'form-control','placeholder'=>'Input user name']); ?>

               </div>

               <div class="form-group">
                     <?php echo Form::label('email', 'Email:'); ?>

                     <?php echo Form::email('email', null,['class'=>'form-control','placeholder'=>'Input user email']); ?>

               </div>

               <div class="form-group">
                     <?php echo Form::label('password', 'Password:'); ?>

                     <?php echo Form::password('password',['class'=>'form-control','placeholder'=>'Input user password']); ?>

               </div>
              <div class="row">
                <div class="col-md-6">
                   <div class="form-group">
                     <?php echo Form::label('role_id', 'Roles:'); ?>

                     <?php echo Form::select('role_id', $roles, null,['class'=>'form-control']); ?>

                   </div>   
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <?php echo Form::label('is_active', 'Status:'); ?>

                      <?php echo Form::select('is_active',array(1=>'Active', 0=>'Not Active'),null,['class'=>'form-control']); ?>

                  </div>
                </div>
              </div>
               <div class="form-group">
                     <?php echo Form::label('photo_id', 'Image:'); ?>

                     <?php echo Form::file('photo_id', ['class'=>'']); ?>

               </div>
               <?php /* <?php echo Form::hidden('role_id', $user->roles->first()->id, []); ?> */ ?>
               <div class="form-group">
                     <?php echo Form::submit('Update User', ['class'=>'btn btn-info']); ?>

               </div>
               
         <?php echo Form::close(); ?>


         </div>
   	</div>
   </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>;

<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(asset('js/libs.js')); ?>"></script>
  
  <script>
   
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>