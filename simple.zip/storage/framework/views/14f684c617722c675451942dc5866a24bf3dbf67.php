<?php $__env->startSection('content'); ?>
    <div class="page-header clearfix">
       <h1><i class="fa fa-users fa-1x"></i> Users 
    <?php if (\Entrust::ability('admin,owner', 'create-post,edit-user')) : ?>
       <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success pull-right"><i class="fa fa-plus fa-fw"></i> Create</a>
    <?php endif; // Entrust::ability ?>
    </h1>
    </div>
	<div class="table-responsive">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Photo</th>
					<th>Name</th>
					<th>Email</th>
					<th>Roles</th>
					<th>Status</th>
					<th>Photo ID</th>
					<th>Options</th>
				</tr>
			</thead>
			<tbody>

        <?php if($users->count()): ?>

        <?php foreach($users as $user): ?>
                 <?php echo e(Debugbar::info($user)); ?>

                 <?php /* <?php echo e(dd($user)); ?> */ ?>
            <tr>
               
                <td><?php echo e($user->id); ?></td>
                <td><img width="50" src="<?php echo e($user->photo? $user->photo->path : 'http://placehold.it/400x400'); ?>" class="img-responsive img-rounded" alt=""> </td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->roles->first()? $user->roles->first()->name : 'No Role'); ?></td>
                <td><?php echo e($user->is_active == 1 ? 'Active':'Not Active'); ?></td>
                <td><?php echo e($user->photo_id); ?></td>
               <?php /*  <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                <td><?php echo e($user->updated_at->diffForHumans()); ?></td> */ ?>
                <td>
                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class=" btn btn-xs btn-primary"><i class="fa fa-edit"></i> Edit</a> 

                    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };">
                   
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php /* <input type="hidden" name="role_id" value="<?php echo e($user->roles->first()->id); ?>"> */ ?>
                        <button type="submit" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</button>
                    </form>
                   <?php /*  <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminUserController@destroy', $user->id]]); ?>

                    <?php echo Form::button('<i class="fa fa-trash-o "></i> Delete', ['type' => 'submit', 'class'=>'btn btn-xs btn-danger']); ?>

                    <?php echo Form::close(); ?> */ ?>
                </td>
            </tr>

        <?php endforeach; ?>
        <?php echo $users->render(); ?>


        <?php else: ?>
            <h3 class="text-center alert alert-info">Empty!</h3>
        <?php endif; ?>

			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('footer'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

 <?php /* <script src="<?php echo e(asset('js/libs.js')); ?>"></script> */ ?>

  <script>
   
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>