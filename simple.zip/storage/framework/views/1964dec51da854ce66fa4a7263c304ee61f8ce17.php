<?php $__env->startSection('content'); ?>
<?php $__env->startSection('header'); ?>
<div class="page-header">
  <h1><i class="fa fa-edit"></i> Posts / Edit #<?php echo e($post->id); ?></h1>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
  <div class="col-md-12">

    <form action="<?php echo e(route('admin.posts.update', $post->id)); ?>" method="POST" enctype="multipart/form-data" accept-charset="UTF-8">
      <input type="hidden" name="_method" value="PUT">
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

      <div class="row">
        <div class="col-md-4 col-sm-4">
          <div class="form-group <?php if($errors->has('user_id')): ?> has-error <?php endif; ?>">
          <label for="user_id-field">Owner</label>
           <input type="text" id="user_id-field" name="user_id" class="form-control" value="<?php echo e(is_null(old("user_id")) ? $post->user_id : old("user_id")); ?>"/>
           <?php if($errors->has("user_id")): ?>
           <span class="help-block"><?php echo e($errors->first("user_id")); ?></span>
           <?php endif; ?>
         </div>
       </div>
       <div class="col-md-4 col-sm-4">
        <div class="form-group <?php if($errors->has('category_id')): ?> has-error <?php endif; ?>">
         <label for="category_id-field">Categories</label>
         <input type="text" id="category_id-field" name="category_id" class="form-control" value="<?php echo e(is_null(old("category_id")) ? $post->category_id : old("category_id")); ?>"/>
         <?php if($errors->has("category_id")): ?>
         <span class="help-block"><?php echo e($errors->first("category_id")); ?></span>
         <?php endif; ?>
       </div>
     </div>
     <div class="col-md-4 col-sm-4">
       <div class="form-group <?php if($errors->has('photo_id')): ?> has-error <?php endif; ?>">
         <label for="photo_id-field">Photo</label>
         <input type="file" id="photo_id-field" name="photo_id" class="" value="<?php echo e(is_null(old("photo_id")) ? $post->photo_id : old("photo_id")); ?>"/>
         <?php if($errors->has("photo_id")): ?>
         <span class="help-block"><?php echo e($errors->first("photo_id")); ?></span>
         <?php endif; ?>
       </div>
     </div>
   </div>



   <div class="form-group <?php if($errors->has('title')): ?> has-error <?php endif; ?>">
     <label for="title-field">Title</label>
     <input type="text" id="title-field" name="title" class="form-control" value="<?php echo e(is_null(old("title")) ? $post->title : old("title")); ?>"/>
     <?php if($errors->has("title")): ?>
     <span class="help-block"><?php echo e($errors->first("title")); ?></span>
     <?php endif; ?>
   </div>
   <div class="form-group <?php if($errors->has('body')): ?> has-error <?php endif; ?>">
     <label for="body-field">Body</label>
     <textarea class="form-control" id="body-field" rows="3" name="body"><?php echo e(is_null(old("body")) ? $post->body : old("body")); ?></textarea>
     <?php if($errors->has("body")): ?>
     <span class="help-block"><?php echo e($errors->first("body")); ?></span>
     <?php endif; ?>
   </div>
   <div class="well well-sm">
    <button type="submit" class="btn btn-primary">Save</button>
    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.posts.index')); ?>"><i class="fa fa-backward"></i>  Back</a>
  </div>
</form>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
<script>
  $('.date-picker').datepicker({
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>