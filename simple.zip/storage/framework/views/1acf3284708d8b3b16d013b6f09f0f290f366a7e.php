<?php $__env->startSection('content'); ?>
<div class="page-header">
  <h1><i class="fa fa-plus"></i> Cimports / Create </h1>
</div>

<?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
  <div class="col-md-12">

    <?php /* <form action="<?php echo e(route('admin.cimportsController.store')); ?>" method="POST"> */ ?>    
    <?php echo Form::open(['action'=>"CimportController@store", 'method'=>"POST",'files'=>true]); ?>

    <?php /* <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> */ ?>   
    <div class="row">
      <div class="col-md-3">
        <div class="form-group <?php if($errors->has('impdate')): ?> has-error <?php endif; ?>">
         <label for="impdate-field">Import Date</label>
         <?php /* <input type="text" id="impdate-field" name="impdate" class="form-control date-picker" value="<?php echo e(old("impdate")); ?>"/> */ ?>
         <?php echo Form::date('impdate', \Carbon\Carbon::now(), ['class'=>'form-control', 'value'=> "<?php echo e(old('impdate')); ?>" ]); ?>

         <?php if($errors->has("impdate")): ?>
         <span class="help-block"><?php echo e($errors->first("impdate")); ?></span>
         <?php endif; ?>
       </div>
     </div>
     <div class="col-md-3">
      <div class="form-group <?php if($errors->has('impindate')): ?> has-error <?php endif; ?>">
       <label for="impindate-field">ImportIn Date</label>
       <?php /* <input type="text" id="impindate-field" name="impindate" class="form-control date-picker" value="<?php echo e(old("impindate")); ?>"/> */ ?>
       <?php echo Form::date('impindate', \Carbon\Carbon::now(), ['class'=>'form-control', 'value'=> "<?php echo e(old('impindate')); ?>" ]); ?>

       <?php if($errors->has("impindate")): ?>
       <span class="help-block"><?php echo e($errors->first("impindate")); ?></span>
       <?php endif; ?>
     </div>     
   </div>
   <div class="col-md-3">
     <div class="form-group <?php if($errors->has('invoicenum')): ?> has-error <?php endif; ?>">
       <label for="invoicenum-field">Invoice Number</label>
       <input type="text" id="invoicenum-field"  minlength="10" name="invoicenum" class="form-control" value="<?php echo e(old("invoicenum")); ?> "/>
       <p class="help-block"></p>
       <?php if($errors->has("invoicenum")): ?>
       <span class="help-block"><?php echo e($errors->first("invoicenum")); ?></span>
       <?php endif; ?>
     </div>
   </div>
   <div class="col-md-3">
     <div class="form-group <?php if($errors->has('totalamount')): ?> has-error <?php endif; ?>">
       <label for="totalamount-field">Total Amount</label>
       <input type="text" id="totalamount-field" name="totalamount" readonly="readonly" class="form-control" value="<?php echo e(old("totalamount")); ?>"/>
       <?php if($errors->has("totalamount")): ?>
       <span class="help-block"><?php echo e($errors->first("totalamount")); ?></span>
       <?php endif; ?>
     </div>
   </div>
 </div>
 <div class="row">
   <div class="col-md-3">
     <div class="form-group <?php if($errors->has('user_id')): ?> has-error <?php endif; ?>">
       <label for="user_id-field">User</label>
       <input type="text" id="user_id-field" name="user_id" readonly="readonly" class="form-control" value="<?php echo e(Auth::user()->name); ?>"/> 
       <?php /* //old("user_id") */ ?>
       <?php if($errors->has("user_id")): ?>
       <span class="help-block"><?php echo e($errors->first("user_id")); ?></span>
       <?php endif; ?>
     </div>
   </div>
   <div class="col-md-3">
     <?php echo Form::label('supplier_id', 'Company Name'); ?>

     <div class="form-group input-group <?php echo e($errors->has('supplier_id') ? 'has-error' :''); ?>">
      <?php echo Form::select('supplier_id',[''=>'Choose Company'] + $suppliers,0,['class'=>'form-control']); ?>

      <?php echo $errors->first('supplier_id','<span class="help-block">:message</span>'); ?>

       <span class="input-group-btn">
          <button class="btn btn-success" type="button"><i class="fa fa-plus"></i></button>
        </span>
    </div>
  </div>
</div>
<div class="row  well">
  <div class="col-md-4">
     <div class="col-md-12">
       <?php echo Form::label('computer_id', 'Computer Name'); ?>

       <div class="form-group input-group <?php echo e($errors->has('computer_id') ? 'has-error' :''); ?>">
        <?php echo Form::select('computer_id',[''=>'Choose Computer'] + $computers,0,['class'=>'form-control']); ?>

        <?php echo $errors->first('computer_id','<span class="help-block">:message</span>'); ?>

           <span class="input-group-btn">
              <button class="btn btn-success" type="button"><i class="fa fa-plus"></i></button>
            </span>
      </div>
    </div>
     <div class="col-md-12">
     <?php echo Form::label('color_id', 'Color'); ?>

     <div class="form-group input-group <?php echo e($errors->has('color_id') ? 'has-error' :''); ?>">
      <?php echo Form::select('color_id',[''=>'Choose Color'] + $colors,0,['class'=>'form-control']); ?>

      <?php echo $errors->first('color_id','<span class="help-block">:message</span>'); ?>

        <span class="input-group-btn">
        <button class="btn btn-success" type="button"><i class="fa fa-plus"></i></button>
      </span>
    </div>
  </div>
  </div>
  <div class="col-md-4">
     <div class="col-md-7">
       <?php echo Form::label('qtyinstock', 'Computer Qty'); ?>

       <div class="form-group <?php echo e($errors->has('qtyinstock') ? 'has-error' :''); ?>">
        <?php echo Form::number('qtyinstock',0,['class'=>'form-control','step'=>'any','placeholder'=>'Computer qtyinstock']); ?>

        <?php echo $errors->first('qtyinstock','<span class="help-block">:message</span>'); ?>

      </div>
    </div>
  </div>
  <div class="col-md-4">
     <div class="col-md-7">
       <?php echo Form::label('sellprice', 'Computer Price'); ?>

       <div class="form-group input-group <?php echo e($errors->has('sellprice') ? 'has-error' :''); ?>">
        <?php echo Form::number('sellprice',0,['class'=>'form-control','step'=>'any','placeholder'=>'Computer sellprice', 'readonly'=>"readonly"]); ?>

        <?php echo $errors->first('sellprice','<span class="help-block">:message</span>'); ?>

         <span class="input-group-btn">
        <button class="btn btn-success editsellprice" type="button"><i class="fa fa-edit"></i></button>
      </div>
    </div>
  </div>
   <div class="col-md-4">
     <div class="col-md-7">
       <?php echo Form::label('cost', 'Computer Cost'); ?>

       <div class="form-group <?php echo e($errors->has('cost') ? 'has-error' :''); ?>">
        <?php echo Form::number('cost',0,['class'=>'form-control','step'=>'any','placeholder'=>'Computer Cost']); ?>

        <?php echo $errors->first('cost','<span class="help-block">:message</span>'); ?>

      </div>
    </div>
  </div>
</div> 
<hr>
<div class="well well-sm">
  <button type="submit" value="newsubmit" name="newsubmit" class="btn btn-success"><i class="fa fa-asterisk"></i> New Import</button>
  <button type="submit" value="addsubmit" name="addsubmit" class="btn btn-warning"><i class="fa fa-download"></i> Add Computer</button>
  <a class="btn btn-link pull-right" href="<?php echo e(route('admin.cimports.index')); ?>"><i class="fa fa-backward"></i> Back</a>
  <button type="submit" value="addsubmit" name="savesubmit" class="btn btn-info pull-right"><i class="fa fa-save"></i> Save Import</button>
</div>
<?php echo Form::close(); ?>

<?php /* </form> */ ?>

</div>
</div>
<div class="row">
  <div class="col-md-12">
    <table class="table table-hover">
      <thead>
        <tr>
          <th>#</th>
          <th>Computer Name</th>
          <th>Color</th>
          <th>Qty</th>
          <th>Cost</th>
          <th>sell Price</th>
          <th>Amount</th>
          <th class="text-right">Option</th>
        </tr>
      </thead>
      <tbody>
      <?php $i = 1; ?>
      <?php foreach($tempcomputers as $tmpcomputerstock): ?>
        <tr>
          <td><?php echo e($i); ?></td>
          <td><?php echo e($tmpcomputerstock->computer_name); ?></td>
          <td><?php echo e($tmpcomputerstock->color_name); ?></td>
          <td class="qty"><?php echo e($tmpcomputerstock->qty); ?></td>
          <td><?php echo e($tmpcomputerstock->cost); ?></td>
          <td><?php echo e($tmpcomputerstock->sellprice); ?></td>
          <td><?php echo e($tmpcomputerstock->cost * $tmpcomputerstock->cost); ?></td>
          <td class="text-right">
             <?php /* <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.tempcomputerstock.show', $category->id)); ?>"><i class="fa fa-eye"></i> View</a> */ ?>
            <a class="btn btn-xs btn-warning" href="<?php echo e(route('admin.tempcomputersotck.edit', $tmpcomputerstock->id)); ?>"><i class="fa fa-edit"></i> Edit</a>
            <form action="<?php echo e(route('admin.tempcomputersotck.destroy', $tmpcomputerstock->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };">
                <input type="hidden" name="_method" value="DELETE">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button type="submit" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</button>
            </form>
              <a class="btn btn-xs btn-info getQty" data-toggle="modal" href='#modal-id'><i class="fa fa-arrow-circle-o-down"></i> Add Serial</a>
          </td>
        </tr>
        <?php $i++; ?>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<div class="modal fade" id="modal-id">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header text-info">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Input Serial</h4>
      </div>
      <div class="modal-body">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <?php /* <?php echo Form::open(['action'=>"TempcomputersotckController@store", 'method'=>"POST", 'id'=>'serialFrom']); ?> */ ?>
            <form action="<?php echo e(route('admin.tempcomputersotck.store')); ?>" method="POST" data-toggle="validator" id='serialForm' name="form1" novalidate>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <?php /* <?php echo $__env->make('forms.Tempcomputersotck', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> */ ?>
            <?php /* <?php for($i = 0; $i < 3; $i++): ?> */ ?>
            <div class="form-group control-group  <?php echo e($errors->has('serialnumber') ? 'has-error' :''); ?>" id="append">
             <?php /*  <?php echo Form::text('serialnumber[]',null,['class'=>'form-control unique  required','placeholder'=>'Computer Serial', 'required'=>"required", 'data-minlength'=>"5"]); ?>

               <div class="help-block with-errors"></div>
              <?php echo $errors->first('serialnumber','<span class="help-block">:message</span>'); ?> */ ?>
             
            </div>
            <?php /* <?php endfor; ?>   */ ?>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="summit" class="btn btn-primary" data-backdrop="static" data-keyboard="false" onclick="findDuplicates();">Save Serial</button>
            </div>
             <?php /* <?php echo Form::close(); ?> */ ?>
             </form>
          </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
<script>
  $('.date-picker').datepicker({
  });
</script>
<script type="text/javascript">

  $(document).ready(function() { 

    var $value = 0;
    $('#serialForm').validator();

    $('.getQty').click(function() {
     var $row = $(this).closest("tr");
     $value = parseInt($row.find(".qty").text());
      $(".modal-body form#serialForm .required").remove()
     $(".modal-body #value").val($value);
        for (var i = 0; i < $value; i++) {
          $("div#append").after('<div class="form-group control-group"> <input type="text" name="serialnumber[]" class="form-control required" placeholder="Input Serial" required="required" data-minlength="5" data-maxlength="25"  value=""/></div><div class="help-block with-errors"></div>');
        }
    });

    // Select2 Auto complete and search 
    $("#computer_id").select2({
      placeholder: "Select a Computer",
       maximumSelectionSize: 2
    }).on('change', function(e){
      var value = e.target.value;
      getComputers(value);
    }); 
    function getComputers(id){
      $.ajax({
        method: 'GET',
        url: '/admin/api/v1/computers/' + id,
        success: function(response) {
          console.log(response);
          $('#sellprice').val(response.sellprice);
          $('.editsellprice').attr('data-json', response);
        },
        error: function(error) {
          console.log(error);
        }
      });
    }
    // edit sellprice
    $('.editsellprice').on('click', function(e) {
      var data = $(this).data('json');
      var price = $('#sellprice').val();
      if(price != data.sellprice) {
        
      }
      $('#sellprice').removeAttr('readonly'); 

    });
    $("#color_id").select2({
      placeholder: "Select a Color",
       maximumSelectionSize: 2
    });
    $("#supplier_id").select2({
      placeholder: "Select a Color",
       maximumSelectionSize: 2
    }); 

    // Validation
      $('#serialForm').validator().on('submit', function (e) {
        if (e.isDefaultPrevented()) {
          // handle the invalid form...
          alert('message');
        } else {
          // everything looks good!
        }
      });
    $("input[unique='serial']").change( function() {
       // check input ($(this).val()) for validity here
       var valueOfChangedInput = $
       (this).val();
       var timeRepeated = 0;
       $("input[unique='serial']").each(function () {
           //Inside each() check the 'valueOfChangedInput' with all other existing input
           if ($(this).val() == valueOfChangedInput ) {
               timeRepeated++; //this will be executed at least 1 time because of the input, which is changed just now
           }
       });

       if(timeRepeated > 1) {
           alert("Duplicate value found !");
           // $('#serialForm').submit( function(ev){
           //          ev.preventDefault();
           //          //later you decide you want to submit
           //   });
       }
       else {
          
        // $("#serialForm").submit( function(ev){
         if(timeRepeated > 1) {
             alert("Duplicate value found !");
              ev.preventDefault();
           }else{
              $("#serialForm").get(0).allowDefault = true;
           }
       // });
             // $("#form1").get(0).allowDefault = true;
       }

   });
  
});
  // Unique validation
  $('#modal-id').on('hidden.bs.modal', function () {
     $(this).find("input").val('').end();
     $("div#append").empty();
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>